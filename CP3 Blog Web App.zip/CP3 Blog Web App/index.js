import express from "express";
import bodyParser from "body-parser";

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({extended : true}));

const blog = {};  //dictionary with title:content

app.use(express.static("public"));

app.get("/", (req, res) => {
    res.render("index.ejs", {data : blog});
})

app.post("/", (req, res) => {
    if (blog[req.body["title_edited"]] != undefined) {
        blog[req.body["title_edited"]] = req.body["content_edited"];
    } else {
        blog[req.body["title"]] = req.body["content"];
    }
    res.render("index.ejs", {data : blog});
})

app.get("/view", (req, res) => {
    res.render("view.ejs");
})

app.post("/view", (req, res) => {
    res.render("view.ejs", {title : req.body["title_clicked"], content : req.body["content_clicked"]});
})

app.get("/edit", (req, res) => {
    res.render("edit.ejs");
})

app.post("/edit", (req, res) => {
    res.render("edit.ejs", {
        title : req.body["title_clicked"], 
        content : req.body["content_clicked"]
    });
})

app.get("/delete", (req, res) => {
    res.render("index.ejs");
})

app.post("/delete", (req, res) => {
    delete blog[req.body["title_clicked"]];
    res.redirect("/");
})

app.listen(port, () => {
    console.log("Server running on port 3000.");
})
